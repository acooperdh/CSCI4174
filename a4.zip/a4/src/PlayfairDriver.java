
public class PlayfairDriver {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Hello World");
        PlayfairMatrix temp = new PlayfairMatrix("drew");
        temp.fillAlphabet();
        //need to test the 3 methods of using this matrix
        //method 1 -> key -> generates matrix
        //method 2 -> matrix & plaintext -> returns ciphertext
        //method 3 -> ciphertext & matrix -> plaintext
        temp.fillMatrix();

    }
}
