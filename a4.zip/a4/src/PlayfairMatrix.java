import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class PlayfairMatrix {
    private char[][] matrix = new char[5][5];
    private char[] key;

    private ArrayList<Character> alphabet = new ArrayList<Character>();
    public PlayfairMatrix(String key){
        String t = key.toUpperCase();
        this.key = t.toCharArray();
    }

    public void fillAlphabet(){
        File alphabetText = new File("alphabet.txt");
        try{
            Scanner fileIn = new Scanner(alphabetText);
            while(fileIn.hasNextLine()){
                String t = fileIn.next();
                char c = t.charAt(0);
                alphabet.add(c);
            }
        }catch (FileNotFoundException e){
            System.out.println("Error has occurred");
            e.printStackTrace();
        }
        System.out.println(alphabet);
    }

    public void fillMatrix(){
        ArrayList<Character> matrixContent = new ArrayList<Character>();
        int count = 0;
        //removing duplicate letters
        for(int i = 0; i<this.key.length; i++){
            if(alphabet.contains(this.key[i])){
                char temp = this.key[i];
                System.out.println(temp);
                int index = alphabet.indexOf(this.key[i]);
                System.out.println("index of "+this.key[i]+" in alphabet is "+index);
                alphabet.remove(index);
                System.out.println("made it past remove");
                alphabet.add(i, this.key[i]);
            }
        }
        System.out.println(alphabet);
    }
}
