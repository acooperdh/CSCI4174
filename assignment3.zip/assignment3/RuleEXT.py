# import Rule from Rule 
# class RuleEXT: 
#     def __init__(self,num, option, transport, source, sourceMask, dest, destMask, port):
#         self.num = num
#         self.option = option
#         self.transport = transport 
#         self.source = source
#         self.soruceArr = source.split(".")
#         self.sourceMask = sourceMask
#         self.sourceMaskArr = sourceMask.split(".")
#         self.sourceSigFigs = 0
#         self.dest = dest
#         self.destArr = dest.split(".")
#         self.destMask = destMask
#         self.destMaskArr = destMask.split(".")
#         self.destSigFigs = 0
#         self.port = port

#         def ruleType(self):
#             return option
        
#         def calcSourceMask(self):
#             self.sourceSigFigs = 0
            
#             for i in range(4):
#                 if(self.)
